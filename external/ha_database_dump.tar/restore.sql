--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4
-- Dumped by pg_dump version 11.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dusterg20;
--
-- Name: dusterg20; Type: DATABASE; Schema: -; Owner: dusterg20
--

CREATE DATABASE dusterg20 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE dusterg20 OWNER TO dusterg20;

\connect dusterg20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: dusterg20
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO dusterg20;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: dusterg20
--

CREATE TABLE public.devices (
    id bigint NOT NULL,
    dev_name character varying(30),
    dev_pi character varying(30),
    dev_location character varying(50),
    dev_pin_count integer,
    dev_pin1 integer,
    dev_pin2 integer,
    dev_pin3 integer,
    dev_pin4 integer,
    dev_pin5 integer,
    dev_data boolean,
    dev_data_type character varying(30),
    dev_data_char character varying(5),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    rpi_id bigint
);


ALTER TABLE public.devices OWNER TO dusterg20;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: dusterg20
--

CREATE SEQUENCE public.devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devices_id_seq OWNER TO dusterg20;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dusterg20
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: microposts; Type: TABLE; Schema: public; Owner: dusterg20
--

CREATE TABLE public.microposts (
    id integer NOT NULL,
    content text,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    picture character varying
);


ALTER TABLE public.microposts OWNER TO dusterg20;

--
-- Name: microposts_id_seq; Type: SEQUENCE; Schema: public; Owner: dusterg20
--

CREATE SEQUENCE public.microposts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.microposts_id_seq OWNER TO dusterg20;

--
-- Name: microposts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dusterg20
--

ALTER SEQUENCE public.microposts_id_seq OWNED BY public.microposts.id;


--
-- Name: relationships; Type: TABLE; Schema: public; Owner: dusterg20
--

CREATE TABLE public.relationships (
    id integer NOT NULL,
    follower_id integer,
    followed_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.relationships OWNER TO dusterg20;

--
-- Name: relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: dusterg20
--

CREATE SEQUENCE public.relationships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.relationships_id_seq OWNER TO dusterg20;

--
-- Name: relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dusterg20
--

ALTER SEQUENCE public.relationships_id_seq OWNED BY public.relationships.id;


--
-- Name: rpis; Type: TABLE; Schema: public; Owner: dusterg20
--

CREATE TABLE public.rpis (
    id bigint NOT NULL,
    rpi_name character varying(30),
    rpi_location character varying(100),
    rpi_ip character varying(16),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    rpi_model character varying
);


ALTER TABLE public.rpis OWNER TO dusterg20;

--
-- Name: rpis_id_seq; Type: SEQUENCE; Schema: public; Owner: dusterg20
--

CREATE SEQUENCE public.rpis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rpis_id_seq OWNER TO dusterg20;

--
-- Name: rpis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dusterg20
--

ALTER SEQUENCE public.rpis_id_seq OWNED BY public.rpis.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: dusterg20
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO dusterg20;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dusterg20
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying,
    email character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    password_digest character varying,
    remember_digest character varying,
    admin boolean DEFAULT false,
    activation_digest character varying,
    activated boolean DEFAULT false,
    activated_at timestamp without time zone,
    reset_digest character varying,
    reset_sent_at timestamp without time zone,
    lname character varying
);


ALTER TABLE public.users OWNER TO dusterg20;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: dusterg20
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO dusterg20;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dusterg20
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: microposts id; Type: DEFAULT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.microposts ALTER COLUMN id SET DEFAULT nextval('public.microposts_id_seq'::regclass);


--
-- Name: relationships id; Type: DEFAULT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.relationships ALTER COLUMN id SET DEFAULT nextval('public.relationships_id_seq'::regclass);


--
-- Name: rpis id; Type: DEFAULT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.rpis ALTER COLUMN id SET DEFAULT nextval('public.rpis_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: dusterg20
--

\i $$PATH$$/3228.dat

--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: dusterg20
--

\i $$PATH$$/3236.dat

--
-- Data for Name: microposts; Type: TABLE DATA; Schema: public; Owner: dusterg20
--

\i $$PATH$$/3232.dat

--
-- Data for Name: relationships; Type: TABLE DATA; Schema: public; Owner: dusterg20
--

\i $$PATH$$/3234.dat

--
-- Data for Name: rpis; Type: TABLE DATA; Schema: public; Owner: dusterg20
--

\i $$PATH$$/3238.dat

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: dusterg20
--

\i $$PATH$$/3227.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dusterg20
--

\i $$PATH$$/3230.dat

--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dusterg20
--

SELECT pg_catalog.setval('public.devices_id_seq', 26, true);


--
-- Name: microposts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dusterg20
--

SELECT pg_catalog.setval('public.microposts_id_seq', 1, false);


--
-- Name: relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dusterg20
--

SELECT pg_catalog.setval('public.relationships_id_seq', 1, false);


--
-- Name: rpis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dusterg20
--

SELECT pg_catalog.setval('public.rpis_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dusterg20
--

SELECT pg_catalog.setval('public.users_id_seq', 11, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: microposts microposts_pkey; Type: CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.microposts
    ADD CONSTRAINT microposts_pkey PRIMARY KEY (id);


--
-- Name: relationships relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT relationships_pkey PRIMARY KEY (id);


--
-- Name: rpis rpis_pkey; Type: CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.rpis
    ADD CONSTRAINT rpis_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_devices_on_dev_name; Type: INDEX; Schema: public; Owner: dusterg20
--

CREATE UNIQUE INDEX index_devices_on_dev_name ON public.devices USING btree (dev_name);


--
-- Name: index_devices_on_rpi_id; Type: INDEX; Schema: public; Owner: dusterg20
--

CREATE INDEX index_devices_on_rpi_id ON public.devices USING btree (rpi_id);


--
-- Name: index_microposts_on_user_id; Type: INDEX; Schema: public; Owner: dusterg20
--

CREATE INDEX index_microposts_on_user_id ON public.microposts USING btree (user_id);


--
-- Name: index_relationships_on_followed_id; Type: INDEX; Schema: public; Owner: dusterg20
--

CREATE INDEX index_relationships_on_followed_id ON public.relationships USING btree (followed_id);


--
-- Name: index_relationships_on_follower_id; Type: INDEX; Schema: public; Owner: dusterg20
--

CREATE INDEX index_relationships_on_follower_id ON public.relationships USING btree (follower_id);


--
-- Name: index_relationships_on_follower_id_and_followed_id; Type: INDEX; Schema: public; Owner: dusterg20
--

CREATE UNIQUE INDEX index_relationships_on_follower_id_and_followed_id ON public.relationships USING btree (follower_id, followed_id);


--
-- Name: index_rpis_on_rpi_name; Type: INDEX; Schema: public; Owner: dusterg20
--

CREATE UNIQUE INDEX index_rpis_on_rpi_name ON public.rpis USING btree (rpi_name);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: dusterg20
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: devices fk_rails_52ab357ed7; Type: FK CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT fk_rails_52ab357ed7 FOREIGN KEY (rpi_id) REFERENCES public.rpis(id);


--
-- Name: microposts fk_rails_558c81314b; Type: FK CONSTRAINT; Schema: public; Owner: dusterg20
--

ALTER TABLE ONLY public.microposts
    ADD CONSTRAINT fk_rails_558c81314b FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres REVOKE ALL ON TABLES  FROM postgres;


--
-- PostgreSQL database dump complete
--

